<?php

namespace Illuminate\Support\Exceptions;

use RuntimeException;

class MathException extends RuntimeException
{
    //
}
