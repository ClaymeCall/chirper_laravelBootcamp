<?php

dataset('{dataset_name}', function () {
    return ['{dataset_element} A', '{dataset_element} B'];
});
