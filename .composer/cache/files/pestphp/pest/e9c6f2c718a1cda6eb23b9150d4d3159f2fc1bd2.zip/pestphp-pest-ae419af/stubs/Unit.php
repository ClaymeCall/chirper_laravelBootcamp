<?php

test('{name}', function () {
    expect(true)->toBeTrue();
});
